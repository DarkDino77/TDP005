#include "World.h"

int main()
{
    World world{};
    world.simulate();

    return 0;
}