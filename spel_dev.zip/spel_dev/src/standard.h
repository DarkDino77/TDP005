#pragma once

#include <iostream>

using std::cout;
using std::endl;
