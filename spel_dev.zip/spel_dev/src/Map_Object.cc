#include "Map_Object.h"

Map_Object::Map_Object(sf::Vector2f const& position, sf::Texture const& sprite)
: Game_Object(position, sprite)
{}
