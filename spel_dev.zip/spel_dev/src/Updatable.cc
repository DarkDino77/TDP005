#include "Updatable.h"

Updatable::Updatable(sf::Vector2f position, sf::Texture const& sprite)
: Game_Object(position, sprite)
{}
