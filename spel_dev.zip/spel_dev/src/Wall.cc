#include "Wall.h"

Wall::Wall(sf::Vector2f const& position, sf::Texture const& sprite)
: Map_Object(position, sprite)
{}
